
public class Get_All_Links extends TestBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
